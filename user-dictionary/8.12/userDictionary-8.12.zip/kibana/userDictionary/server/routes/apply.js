"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.registerApplyRoute = registerApplyRoute;
var _ssh = require("ssh2");
var _configSchema = require("@kbn/config-schema");
/*
 * Copyright Elasticsearch B.V. and/or licensed to Elasticsearch B.V. under one
 * or more contributor license agreements. Licensed under the Elastic License
 * 2.0 and the Server Side Public License, v 1; you may not use this file except
 * in compliance with, at your election, the Elastic License 2.0 or the Server
 * Side Public License, v 1.
 */

// Userdic config tpye name
const objectTypeName = 'user_dictionary_config';

/**
 *
 * @param router Registers a get route that returns a random number between one and ten. It has no input
 * parameters, and returns a random number in the body.
 */
function registerApplyRoute(router) {
  router.post({
    path: '/api/mzc/apply',
    validate: {
      body: _configSchema.schema.object({
        data: _configSchema.schema.string(),
        fileName: _configSchema.schema.string()
      })
    }
  }, async (context, request, response) => {
    var _request$body, _request$body2;
    const fileData = (_request$body = request.body) === null || _request$body === void 0 ? void 0 : _request$body.data;
    const fileName = (_request$body2 = request.body) === null || _request$body2 === void 0 ? void 0 : _request$body2.fileName;
    let username = '';
    let password = '';
    let dirPath = '';
    let port = 0;
    if (fileData && fileData.length <= 1) return response.badRequest({
      body: "File is empty!"
    });

    // 원격 호스트 정보 불러오기
    const savedObjectsClient = (await context.core).savedObjects.client;
    try {
      const findObject = await savedObjectsClient.find({
        type: objectTypeName
      });
      let objectId = '';
      if ((findObject === null || findObject === void 0 ? void 0 : findObject.total) > 0) {
        objectId = findObject.saved_objects[0].id;
        console.log(objectId);
        let savedObject = await savedObjectsClient.get(objectTypeName, objectId);
        username = (savedObject === null || savedObject === void 0 ? void 0 : savedObject.attributes.username) || '';
        password = (savedObject === null || savedObject === void 0 ? void 0 : savedObject.attributes.password) || '';
        port = Number(savedObject === null || savedObject === void 0 ? void 0 : savedObject.attributes.port) || 0;
        dirPath = (savedObject === null || savedObject === void 0 ? void 0 : savedObject.attributes.dirPath) || '';
      } else {
        return response.conflict({
          body: "Not found configuration"
        });
      }
    } catch (error) {
      return response.conflict({
        body: "Not found configuration"
      });
    }
    const client = (await context.core).elasticsearch.client.asCurrentUser;

    // 파일이 전송될 호스트 조회
    let hosts = [];
    const nodes = await client.nodes.info();
    Object.keys(nodes.nodes).forEach(key => {
      hosts.push(nodes.nodes[key].host);
    });

    // 데이터 엘라스틱 서버에 전송
    const conn = new _ssh.Client();
    console.log(fileName);
    const saveFileName = fileName + '.txt';
    let h = '34.64.201.13';
    for (const host of hosts) {
      await transferFileToHost(h, saveFileName, dirPath, fileData, port, username, password);
    }

    // index reload
    // try {
    //   const res = await client.transport.request({
    //     method: 'POST',
    //     path: '/search-elastic-docs-crawler/_reload_search_analyzers',
    //   });
    //   console.log(res);
    // } catch (error) {
    //   return response.conflict({
    //     body: "index reload failed"
    //   });
    // }

    return response.ok({
      body: hosts
    });
  });
}
async function transferFileToHost(host, fileName, remotePath, fileData, port, username, password) {
  return new Promise((resolve, reject) => {
    const conn = new _ssh.Client();
    conn.on('ready', () => {
      console.log('Client :: ready');
      conn.sftp((err, sftp) => {
        if (err) reject(err);

        // 디렉토리 생성 (동기적으로 수행)
        sftp.mkdir(remotePath, err => {
          if (err && err.code !== 4) reject(err); // code 4는 디렉토리가 이미 존재함을 의미

          const writeStream = sftp.createWriteStream(remotePath + '/' + fileName);
          writeStream.write(fileData, err => {
            if (err) {
              reject(err);
            } else {
              console.log('Write Complete');
              conn.end(); // 연결 종료
              resolve();
            }
          });
        });
      });
    }).connect({
      host: host,
      port: port,
      username: username,
      password: password
    });
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfc3NoIiwicmVxdWlyZSIsIl9jb25maWdTY2hlbWEiLCJvYmplY3RUeXBlTmFtZSIsInJlZ2lzdGVyQXBwbHlSb3V0ZSIsInJvdXRlciIsInBvc3QiLCJwYXRoIiwidmFsaWRhdGUiLCJib2R5Iiwic2NoZW1hIiwib2JqZWN0IiwiZGF0YSIsInN0cmluZyIsImZpbGVOYW1lIiwiY29udGV4dCIsInJlcXVlc3QiLCJyZXNwb25zZSIsIl9yZXF1ZXN0JGJvZHkiLCJfcmVxdWVzdCRib2R5MiIsImZpbGVEYXRhIiwidXNlcm5hbWUiLCJwYXNzd29yZCIsImRpclBhdGgiLCJwb3J0IiwibGVuZ3RoIiwiYmFkUmVxdWVzdCIsInNhdmVkT2JqZWN0c0NsaWVudCIsImNvcmUiLCJzYXZlZE9iamVjdHMiLCJjbGllbnQiLCJmaW5kT2JqZWN0IiwiZmluZCIsInR5cGUiLCJvYmplY3RJZCIsInRvdGFsIiwic2F2ZWRfb2JqZWN0cyIsImlkIiwiY29uc29sZSIsImxvZyIsInNhdmVkT2JqZWN0IiwiZ2V0IiwiYXR0cmlidXRlcyIsIk51bWJlciIsImNvbmZsaWN0IiwiZXJyb3IiLCJlbGFzdGljc2VhcmNoIiwiYXNDdXJyZW50VXNlciIsImhvc3RzIiwibm9kZXMiLCJpbmZvIiwiT2JqZWN0Iiwia2V5cyIsImZvckVhY2giLCJrZXkiLCJwdXNoIiwiaG9zdCIsImNvbm4iLCJDbGllbnQiLCJzYXZlRmlsZU5hbWUiLCJoIiwidHJhbnNmZXJGaWxlVG9Ib3N0Iiwib2siLCJyZW1vdGVQYXRoIiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZWplY3QiLCJvbiIsInNmdHAiLCJlcnIiLCJta2RpciIsImNvZGUiLCJ3cml0ZVN0cmVhbSIsImNyZWF0ZVdyaXRlU3RyZWFtIiwid3JpdGUiLCJlbmQiLCJjb25uZWN0Il0sInNvdXJjZXMiOlsiYXBwbHkudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIENvcHlyaWdodCBFbGFzdGljc2VhcmNoIEIuVi4gYW5kL29yIGxpY2Vuc2VkIHRvIEVsYXN0aWNzZWFyY2ggQi5WLiB1bmRlciBvbmVcbiAqIG9yIG1vcmUgY29udHJpYnV0b3IgbGljZW5zZSBhZ3JlZW1lbnRzLiBMaWNlbnNlZCB1bmRlciB0aGUgRWxhc3RpYyBMaWNlbnNlXG4gKiAyLjAgYW5kIHRoZSBTZXJ2ZXIgU2lkZSBQdWJsaWMgTGljZW5zZSwgdiAxOyB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdFxuICogaW4gY29tcGxpYW5jZSB3aXRoLCBhdCB5b3VyIGVsZWN0aW9uLCB0aGUgRWxhc3RpYyBMaWNlbnNlIDIuMCBvciB0aGUgU2VydmVyXG4gKiBTaWRlIFB1YmxpYyBMaWNlbnNlLCB2IDEuXG4gKi9cbmltcG9ydCB7IENsaWVudCwgU0ZUUFdyYXBwZXIgfSBmcm9tICdzc2gyJztcbmltcG9ydCB7IHNjaGVtYSB9IGZyb20gJ0BrYm4vY29uZmlnLXNjaGVtYSc7XG5pbXBvcnQgeyBJUm91dGVyIH0gZnJvbSAnQGtibi9jb3JlL3NlcnZlcic7XG5cbi8vIFVzZXJkaWMgY29uZmlnIHRweWUgbmFtZVxuY29uc3Qgb2JqZWN0VHlwZU5hbWUgPSAndXNlcl9kaWN0aW9uYXJ5X2NvbmZpZyc7XG5cbi8qKlxuICpcbiAqIEBwYXJhbSByb3V0ZXIgUmVnaXN0ZXJzIGEgZ2V0IHJvdXRlIHRoYXQgcmV0dXJucyBhIHJhbmRvbSBudW1iZXIgYmV0d2VlbiBvbmUgYW5kIHRlbi4gSXQgaGFzIG5vIGlucHV0XG4gKiBwYXJhbWV0ZXJzLCBhbmQgcmV0dXJucyBhIHJhbmRvbSBudW1iZXIgaW4gdGhlIGJvZHkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZWdpc3RlckFwcGx5Um91dGUocm91dGVyOiBJUm91dGVyKSB7XG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL216Yy9hcHBseScsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBkYXRhOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgZmlsZU5hbWU6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICBjb25zdCBmaWxlRGF0YTogc3RyaW5nID0gcmVxdWVzdC5ib2R5Py5kYXRhO1xuICAgICAgY29uc3QgZmlsZU5hbWU6IHN0cmluZyA9IHJlcXVlc3QuYm9keT8uZmlsZU5hbWU7XG5cbiAgICAgIGxldCB1c2VybmFtZTogc3RyaW5nID0gJyc7XG4gICAgICBsZXQgcGFzc3dvcmQ6IHN0cmluZyA9ICcnO1xuICAgICAgbGV0IGRpclBhdGg6IHN0cmluZyA9ICcnO1xuICAgICAgbGV0IHBvcnQ6IG51bWJlciA9IDA7XG5cbiAgICAgIGlmIChmaWxlRGF0YSAmJiBmaWxlRGF0YS5sZW5ndGggPD0gMSlcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmJhZFJlcXVlc3Qoe1xuICAgICAgICAgIGJvZHk6IFwiRmlsZSBpcyBlbXB0eSFcIlxuICAgICAgICB9KTtcblxuXG4gICAgICAvLyDsm5Dqsqkg7Zi47Iqk7Yq4IOygleuztCDrtojrn6zsmKTquLBcbiAgICAgIGNvbnN0IHNhdmVkT2JqZWN0c0NsaWVudCA9IChhd2FpdCBjb250ZXh0LmNvcmUpLnNhdmVkT2JqZWN0cy5jbGllbnQ7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBmaW5kT2JqZWN0ID0gYXdhaXQgc2F2ZWRPYmplY3RzQ2xpZW50LmZpbmQoeyB0eXBlOiBvYmplY3RUeXBlTmFtZSB9KTtcbiAgICAgICAgbGV0IG9iamVjdElkID0gJyc7XG5cbiAgICAgICAgaWYgKGZpbmRPYmplY3Q/LnRvdGFsID4gMCkge1xuICAgICAgICAgIG9iamVjdElkID0gZmluZE9iamVjdC5zYXZlZF9vYmplY3RzWzBdLmlkXG4gICAgICAgICAgY29uc29sZS5sb2cob2JqZWN0SWQpO1xuXG4gICAgICAgICAgbGV0IHNhdmVkT2JqZWN0OiBhbnkgPSBhd2FpdCBzYXZlZE9iamVjdHNDbGllbnQuZ2V0KG9iamVjdFR5cGVOYW1lLCBvYmplY3RJZCk7XG4gICAgICAgICAgdXNlcm5hbWUgPSBzYXZlZE9iamVjdD8uYXR0cmlidXRlcy51c2VybmFtZSB8fCAnJztcbiAgICAgICAgICBwYXNzd29yZCA9IHNhdmVkT2JqZWN0Py5hdHRyaWJ1dGVzLnBhc3N3b3JkIHx8ICcnO1xuICAgICAgICAgIHBvcnQgPSBOdW1iZXIoc2F2ZWRPYmplY3Q/LmF0dHJpYnV0ZXMucG9ydCkgfHwgMDtcbiAgICAgICAgICBkaXJQYXRoID0gc2F2ZWRPYmplY3Q/LmF0dHJpYnV0ZXMuZGlyUGF0aCB8fCAnJztcblxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiByZXNwb25zZS5jb25mbGljdCh7IGJvZHk6IFwiTm90IGZvdW5kIGNvbmZpZ3VyYXRpb25cIiB9KVxuICAgICAgICB9XG5cbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5jb25mbGljdCh7XG4gICAgICAgICAgYm9keTogXCJOb3QgZm91bmQgY29uZmlndXJhdGlvblwiXG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBjbGllbnQgPSAoYXdhaXQgY29udGV4dC5jb3JlKS5lbGFzdGljc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xuXG4gICAgICAvLyDtjIzsnbzsnbQg7KCE7Iah65CgIO2YuOyKpO2KuCDsobDtmoxcbiAgICAgIGxldCBob3N0czogQXJyYXk8c3RyaW5nPiA9IFtdO1xuICAgICAgY29uc3Qgbm9kZXMgPSBhd2FpdCBjbGllbnQubm9kZXMuaW5mbygpO1xuICAgICAgT2JqZWN0LmtleXMobm9kZXMubm9kZXMpLmZvckVhY2goKGtleSkgPT4ge1xuICAgICAgICBob3N0cy5wdXNoKG5vZGVzLm5vZGVzW2tleV0uaG9zdCk7XG4gICAgICB9KVxuXG4gICAgICAvLyDrjbDsnbTthLAg7JeY65287Iqk7YuxIOyEnOuyhOyXkCDsoITshqFcbiAgICAgIGNvbnN0IGNvbm4gPSBuZXcgQ2xpZW50KCk7XG4gICAgICBjb25zb2xlLmxvZyhmaWxlTmFtZSlcbiAgICAgIGNvbnN0IHNhdmVGaWxlTmFtZSA9IGZpbGVOYW1lICsgJy50eHQnO1xuICAgICAgbGV0IGggPSAnMzQuNjQuMjAxLjEzJztcblxuICAgICAgZm9yIChjb25zdCBob3N0IG9mIGhvc3RzKSB7XG4gICAgICAgIGF3YWl0IHRyYW5zZmVyRmlsZVRvSG9zdChoLCBzYXZlRmlsZU5hbWUsIGRpclBhdGgsIGZpbGVEYXRhLCBwb3J0LCB1c2VybmFtZSwgcGFzc3dvcmQpO1xuICAgICAgfVxuXG4gICAgICAvLyBpbmRleCByZWxvYWRcbiAgICAgIC8vIHRyeSB7XG4gICAgICAvLyAgIGNvbnN0IHJlcyA9IGF3YWl0IGNsaWVudC50cmFuc3BvcnQucmVxdWVzdCh7XG4gICAgICAvLyAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAvLyAgICAgcGF0aDogJy9zZWFyY2gtZWxhc3RpYy1kb2NzLWNyYXdsZXIvX3JlbG9hZF9zZWFyY2hfYW5hbHl6ZXJzJyxcbiAgICAgIC8vICAgfSk7XG4gICAgICAvLyAgIGNvbnNvbGUubG9nKHJlcyk7XG4gICAgICAvLyB9IGNhdGNoIChlcnJvcikge1xuICAgICAgLy8gICByZXR1cm4gcmVzcG9uc2UuY29uZmxpY3Qoe1xuICAgICAgLy8gICAgIGJvZHk6IFwiaW5kZXggcmVsb2FkIGZhaWxlZFwiXG4gICAgICAvLyAgIH0pO1xuICAgICAgLy8gfVxuXG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICBib2R5OiBob3N0cyxcbiAgICAgIH0pO1xuICAgIH1cbiAgKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gdHJhbnNmZXJGaWxlVG9Ib3N0KFxuICBob3N0OiBzdHJpbmcsXG4gIGZpbGVOYW1lOiBzdHJpbmcsXG4gIHJlbW90ZVBhdGg6IHN0cmluZyxcbiAgZmlsZURhdGE6IHN0cmluZyxcbiAgcG9ydDogbnVtYmVyLFxuICB1c2VybmFtZTogc3RyaW5nLFxuICBwYXNzd29yZDogc3RyaW5nLFxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgY29uc3QgY29ubiA9IG5ldyBDbGllbnQoKTtcbiAgICBjb25uLm9uKCdyZWFkeScsICgpID0+IHtcbiAgICAgIGNvbnNvbGUubG9nKCdDbGllbnQgOjogcmVhZHknKTtcbiAgICAgIGNvbm4uc2Z0cCgoZXJyLCBzZnRwKSA9PiB7XG4gICAgICAgIGlmIChlcnIpIHJlamVjdChlcnIpO1xuXG4gICAgICAgIC8vIOuUlOugie2GoOumrCDsg53shLEgKOuPmeq4sOyggeycvOuhnCDsiJjtlokpXG4gICAgICAgIHNmdHAubWtkaXIocmVtb3RlUGF0aCwgKGVycikgPT4ge1xuICAgICAgICAgIGlmIChlcnIgJiYgZXJyLmNvZGUgIT09IDQpIHJlamVjdChlcnIpOyAvLyBjb2RlIDTripQg65SU66CJ7Yag66as6rCAIOydtOuvuCDsobTsnqztlajsnYQg7J2Y66+4XG5cbiAgICAgICAgICBjb25zdCB3cml0ZVN0cmVhbSA9IHNmdHAuY3JlYXRlV3JpdGVTdHJlYW0ocmVtb3RlUGF0aCArICcvJyArIGZpbGVOYW1lKTtcbiAgICAgICAgICB3cml0ZVN0cmVhbS53cml0ZShmaWxlRGF0YSwgKGVycikgPT4ge1xuICAgICAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgICAgICByZWplY3QoZXJyKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdXcml0ZSBDb21wbGV0ZScpO1xuICAgICAgICAgICAgICBjb25uLmVuZCgpOyAvLyDsl7DqsrAg7KKF66OMXG4gICAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9KS5jb25uZWN0KHtcbiAgICAgIGhvc3Q6IGhvc3QsXG4gICAgICBwb3J0OiBwb3J0LFxuICAgICAgdXNlcm5hbWU6IHVzZXJuYW1lLFxuICAgICAgcGFzc3dvcmQ6IHBhc3N3b3JkLFxuICAgIH0pO1xuICB9KTtcbn0iXSwibWFwcGluZ3MiOiI7Ozs7OztBQU9BLElBQUFBLElBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLGFBQUEsR0FBQUQsT0FBQTtBQVJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUtBO0FBQ0EsTUFBTUUsY0FBYyxHQUFHLHdCQUF3Qjs7QUFFL0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNDLGtCQUFrQkEsQ0FBQ0MsTUFBZSxFQUFFO0VBQ2xEQSxNQUFNLENBQUNDLElBQUksQ0FDVDtJQUNFQyxJQUFJLEVBQUUsZ0JBQWdCO0lBQ3RCQyxRQUFRLEVBQUU7TUFDUkMsSUFBSSxFQUFFQyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbEJDLElBQUksRUFBRUYsb0JBQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUM7UUFDckJDLFFBQVEsRUFBRUosb0JBQU0sQ0FBQ0csTUFBTSxDQUFDO01BQzFCLENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPRSxPQUFPLEVBQUVDLE9BQU8sRUFBRUMsUUFBUSxLQUFLO0lBQUEsSUFBQUMsYUFBQSxFQUFBQyxjQUFBO0lBQ3BDLE1BQU1DLFFBQWdCLElBQUFGLGFBQUEsR0FBR0YsT0FBTyxDQUFDUCxJQUFJLGNBQUFTLGFBQUEsdUJBQVpBLGFBQUEsQ0FBY04sSUFBSTtJQUMzQyxNQUFNRSxRQUFnQixJQUFBSyxjQUFBLEdBQUdILE9BQU8sQ0FBQ1AsSUFBSSxjQUFBVSxjQUFBLHVCQUFaQSxjQUFBLENBQWNMLFFBQVE7SUFFL0MsSUFBSU8sUUFBZ0IsR0FBRyxFQUFFO0lBQ3pCLElBQUlDLFFBQWdCLEdBQUcsRUFBRTtJQUN6QixJQUFJQyxPQUFlLEdBQUcsRUFBRTtJQUN4QixJQUFJQyxJQUFZLEdBQUcsQ0FBQztJQUVwQixJQUFJSixRQUFRLElBQUlBLFFBQVEsQ0FBQ0ssTUFBTSxJQUFJLENBQUMsRUFDbEMsT0FBT1IsUUFBUSxDQUFDUyxVQUFVLENBQUM7TUFDekJqQixJQUFJLEVBQUU7SUFDUixDQUFDLENBQUM7O0lBR0o7SUFDQSxNQUFNa0Isa0JBQWtCLEdBQUcsQ0FBQyxNQUFNWixPQUFPLENBQUNhLElBQUksRUFBRUMsWUFBWSxDQUFDQyxNQUFNO0lBQ25FLElBQUk7TUFDRixNQUFNQyxVQUFVLEdBQUcsTUFBTUosa0JBQWtCLENBQUNLLElBQUksQ0FBQztRQUFFQyxJQUFJLEVBQUU5QjtNQUFlLENBQUMsQ0FBQztNQUMxRSxJQUFJK0IsUUFBUSxHQUFHLEVBQUU7TUFFakIsSUFBSSxDQUFBSCxVQUFVLGFBQVZBLFVBQVUsdUJBQVZBLFVBQVUsQ0FBRUksS0FBSyxJQUFHLENBQUMsRUFBRTtRQUN6QkQsUUFBUSxHQUFHSCxVQUFVLENBQUNLLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsRUFBRTtRQUN6Q0MsT0FBTyxDQUFDQyxHQUFHLENBQUNMLFFBQVEsQ0FBQztRQUVyQixJQUFJTSxXQUFnQixHQUFHLE1BQU1iLGtCQUFrQixDQUFDYyxHQUFHLENBQUN0QyxjQUFjLEVBQUUrQixRQUFRLENBQUM7UUFDN0ViLFFBQVEsR0FBRyxDQUFBbUIsV0FBVyxhQUFYQSxXQUFXLHVCQUFYQSxXQUFXLENBQUVFLFVBQVUsQ0FBQ3JCLFFBQVEsS0FBSSxFQUFFO1FBQ2pEQyxRQUFRLEdBQUcsQ0FBQWtCLFdBQVcsYUFBWEEsV0FBVyx1QkFBWEEsV0FBVyxDQUFFRSxVQUFVLENBQUNwQixRQUFRLEtBQUksRUFBRTtRQUNqREUsSUFBSSxHQUFHbUIsTUFBTSxDQUFDSCxXQUFXLGFBQVhBLFdBQVcsdUJBQVhBLFdBQVcsQ0FBRUUsVUFBVSxDQUFDbEIsSUFBSSxDQUFDLElBQUksQ0FBQztRQUNoREQsT0FBTyxHQUFHLENBQUFpQixXQUFXLGFBQVhBLFdBQVcsdUJBQVhBLFdBQVcsQ0FBRUUsVUFBVSxDQUFDbkIsT0FBTyxLQUFJLEVBQUU7TUFFakQsQ0FBQyxNQUFNO1FBQ0wsT0FBT04sUUFBUSxDQUFDMkIsUUFBUSxDQUFDO1VBQUVuQyxJQUFJLEVBQUU7UUFBMEIsQ0FBQyxDQUFDO01BQy9EO0lBRUYsQ0FBQyxDQUFDLE9BQU9vQyxLQUFLLEVBQUU7TUFDZCxPQUFPNUIsUUFBUSxDQUFDMkIsUUFBUSxDQUFDO1FBQ3ZCbkMsSUFBSSxFQUFFO01BQ1IsQ0FBQyxDQUFDO0lBQ0o7SUFFQSxNQUFNcUIsTUFBTSxHQUFHLENBQUMsTUFBTWYsT0FBTyxDQUFDYSxJQUFJLEVBQUVrQixhQUFhLENBQUNoQixNQUFNLENBQUNpQixhQUFhOztJQUV0RTtJQUNBLElBQUlDLEtBQW9CLEdBQUcsRUFBRTtJQUM3QixNQUFNQyxLQUFLLEdBQUcsTUFBTW5CLE1BQU0sQ0FBQ21CLEtBQUssQ0FBQ0MsSUFBSSxDQUFDLENBQUM7SUFDdkNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDSCxLQUFLLENBQUNBLEtBQUssQ0FBQyxDQUFDSSxPQUFPLENBQUVDLEdBQUcsSUFBSztNQUN4Q04sS0FBSyxDQUFDTyxJQUFJLENBQUNOLEtBQUssQ0FBQ0EsS0FBSyxDQUFDSyxHQUFHLENBQUMsQ0FBQ0UsSUFBSSxDQUFDO0lBQ25DLENBQUMsQ0FBQzs7SUFFRjtJQUNBLE1BQU1DLElBQUksR0FBRyxJQUFJQyxXQUFNLENBQUMsQ0FBQztJQUN6QnBCLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDekIsUUFBUSxDQUFDO0lBQ3JCLE1BQU02QyxZQUFZLEdBQUc3QyxRQUFRLEdBQUcsTUFBTTtJQUN0QyxJQUFJOEMsQ0FBQyxHQUFHLGNBQWM7SUFFdEIsS0FBSyxNQUFNSixJQUFJLElBQUlSLEtBQUssRUFBRTtNQUN4QixNQUFNYSxrQkFBa0IsQ0FBQ0QsQ0FBQyxFQUFFRCxZQUFZLEVBQUVwQyxPQUFPLEVBQUVILFFBQVEsRUFBRUksSUFBSSxFQUFFSCxRQUFRLEVBQUVDLFFBQVEsQ0FBQztJQUN4Rjs7SUFFQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7O0lBRUEsT0FBT0wsUUFBUSxDQUFDNkMsRUFBRSxDQUFDO01BQ2pCckQsSUFBSSxFQUFFdUM7SUFDUixDQUFDLENBQUM7RUFDSixDQUNGLENBQUM7QUFDSDtBQUVBLGVBQWVhLGtCQUFrQkEsQ0FDL0JMLElBQVksRUFDWjFDLFFBQWdCLEVBQ2hCaUQsVUFBa0IsRUFDbEIzQyxRQUFnQixFQUNoQkksSUFBWSxFQUNaSCxRQUFnQixFQUNoQkMsUUFBZ0IsRUFDRDtFQUNmLE9BQU8sSUFBSTBDLE9BQU8sQ0FBQyxDQUFDQyxPQUFPLEVBQUVDLE1BQU0sS0FBSztJQUN0QyxNQUFNVCxJQUFJLEdBQUcsSUFBSUMsV0FBTSxDQUFDLENBQUM7SUFDekJELElBQUksQ0FBQ1UsRUFBRSxDQUFDLE9BQU8sRUFBRSxNQUFNO01BQ3JCN0IsT0FBTyxDQUFDQyxHQUFHLENBQUMsaUJBQWlCLENBQUM7TUFDOUJrQixJQUFJLENBQUNXLElBQUksQ0FBQyxDQUFDQyxHQUFHLEVBQUVELElBQUksS0FBSztRQUN2QixJQUFJQyxHQUFHLEVBQUVILE1BQU0sQ0FBQ0csR0FBRyxDQUFDOztRQUVwQjtRQUNBRCxJQUFJLENBQUNFLEtBQUssQ0FBQ1AsVUFBVSxFQUFHTSxHQUFHLElBQUs7VUFDOUIsSUFBSUEsR0FBRyxJQUFJQSxHQUFHLENBQUNFLElBQUksS0FBSyxDQUFDLEVBQUVMLE1BQU0sQ0FBQ0csR0FBRyxDQUFDLENBQUMsQ0FBQzs7VUFFeEMsTUFBTUcsV0FBVyxHQUFHSixJQUFJLENBQUNLLGlCQUFpQixDQUFDVixVQUFVLEdBQUcsR0FBRyxHQUFHakQsUUFBUSxDQUFDO1VBQ3ZFMEQsV0FBVyxDQUFDRSxLQUFLLENBQUN0RCxRQUFRLEVBQUdpRCxHQUFHLElBQUs7WUFDbkMsSUFBSUEsR0FBRyxFQUFFO2NBQ1BILE1BQU0sQ0FBQ0csR0FBRyxDQUFDO1lBQ2IsQ0FBQyxNQUFNO2NBQ0wvQixPQUFPLENBQUNDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztjQUM3QmtCLElBQUksQ0FBQ2tCLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztjQUNaVixPQUFPLENBQUMsQ0FBQztZQUNYO1VBQ0YsQ0FBQyxDQUFDO1FBQ0osQ0FBQyxDQUFDO01BQ0osQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDLENBQUNXLE9BQU8sQ0FBQztNQUNUcEIsSUFBSSxFQUFFQSxJQUFJO01BQ1ZoQyxJQUFJLEVBQUVBLElBQUk7TUFDVkgsUUFBUSxFQUFFQSxRQUFRO01BQ2xCQyxRQUFRLEVBQUVBO0lBQ1osQ0FBQyxDQUFDO0VBQ0osQ0FBQyxDQUFDO0FBQ0oifQ==